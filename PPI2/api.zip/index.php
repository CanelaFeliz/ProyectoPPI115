﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NIXGARU – Iniciar Sesión</title>
  <!-- Google Fonts: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="CSS/style.css">
</head>
<body class="login-body">

  <main class="login-container">
    <div class="login-card">
      
      <!-- Encabezado de la Tarjeta con Ícono Circular de Café -->
      <div class="login-header">
        <div class="login-logo-circle">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
            <line x1="6" y1="1" x2="6" y2="4"></line>
            <line x1="10" y1="1" x2="10" y2="4"></line>
            <line x1="14" y1="1" x2="14" y2="4"></line>
          </svg>
        </div>
        <h1 class="login-title">NIXGARU</h1>
        <p class="login-subtitle">Inicie sesión en su cuenta</p>
      </div>

      <!-- Formulario de Inicio de Sesión -->
      <form id="formLogin" class="login-form">
        
        <!-- Campo: Usuario -->
        <div class="login-form-group">
          <label for="inputUsuario" class="login-label">Usuario</label>
          <div class="login-input-wrapper">
            <svg class="login-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            <input 
              type="text" 
              id="inputUsuario" 
              class="login-input" 
              placeholder="Ingrese su usuario o ID de empleado" 
              required 
              autocomplete="username"
            >
          </div>
        </div>

        <!-- Campo: Contraseña -->
        <div class="login-form-group">
          <label for="inputPassword" class="login-label">Contraseña</label>
          <div class="login-input-wrapper">
            <svg class="login-input-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
            </svg>
            <input 
              type="password" 
              id="inputPassword" 
              class="login-input login-input-password" 
              placeholder="••••••••••••" 
              required 
              autocomplete="current-password"
            >
            <button 
              type="button" 
              id="btnTogglePassword" 
              class="btn-toggle-eye" 
              aria-label="Mostrar u ocultar contraseña"
              title="Mostrar u ocultar contraseña"
            >
              <!-- Icono Ojo (Visible por defecto) -->
              <svg class="icon-eye" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
              <!-- Icono Ojo Tachado (Oculto por defecto) -->
              <svg class="icon-eye-off" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: none;">
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                <line x1="1" y1="1" x2="23" y2="23"></line>
              </svg>
            </button>
          </div>
        </div>

        <!-- Botón de Ingreso con Color de Acento (#0D6EFD) -->
        <button type="submit" id="btnLoginSubmit" class="btn-login-submit">
          Ingresar al Sistema
        </button>

      </form>

      <!-- Pie de la Tarjeta -->
      <div class="login-footer">
        <p class="login-footer-text">
          ¿Olvidó su contraseña? <a href="#" class="login-link-admin">Contacte al administrador</a>
        </p>
      </div>

    </div>
  </main>

  <script src="JS/main.js"></script>
</body>
</html>
