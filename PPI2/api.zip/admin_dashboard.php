﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NIXGARU – Resumen Analítico</title>
  <!-- Google Fonts: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="CSS/style.css">
</head>
<body class="admin-body">

  <div class="admin-layout">

    <!-- BARRA LATERAL (SIDEBAR ADMIN OSCURA #382823) -->
    <aside class="admin-sidebar">
      
      <!-- Logotipo Admin -->
      <div class="admin-brand">
        <div class="admin-brand-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
            <line x1="6" y1="1" x2="6" y2="4"></line>
            <line x1="10" y1="1" x2="10" y2="4"></line>
            <line x1="14" y1="1" x2="14" y2="4"></line>
          </svg>
        </div>
        <div class="admin-brand-info">
          <span class="admin-brand-title">NIXGARU</span>
          <span class="admin-brand-sub">ADMINISTRACION</span>
        </div>
      </div>

      <!-- Menú de Navegación del Administrador -->
      <nav class="admin-nav">
        <!-- Catálogo y Menú (Enlace a admin_catalogo.php) -->
        <a href="admin_catalogo.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
          </svg>
          <span>Catálogo y Menú</span>
        </a>

        <!-- Gestión de Mesas (Enlace a admin_mesas.php) -->
        <a href="admin_mesas.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 3h18v18H3zM3 9h18M9 21V9"></path>
          </svg>
          <span>Gestión de Mesas</span>
        </a>

        <!-- Control de Inventarios (Enlace a admin_inventario.php) -->
        <a href="admin_inventario.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
            <line x1="12" y1="22.08" x2="12" y2="12"></line>
          </svg>
          <span>Control de Inventarios</span>
        </a>

        <!-- Cuentas de Personal (Enlace a admin_personal.php) -->
        <a href="admin_personal.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span>Cuentas de Personal</span>
        </a>

        <!-- Análisis y Reportes (ACTIVO: Fondo blanco, texto oscuro y bordes redondeados) -->
        <a href="admin_dashboard.php" class="admin-nav-item active">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="20" x2="18" y2="10"></line>
            <line x1="12" y1="20" x2="12" y2="4"></line>
            <line x1="6" y1="20" x2="6" y2="14"></line>
          </svg>
          <span>Análisis y Reportes</span>
        </a>
      </nav>

      <!-- Perfil de Administrador en el pie de la barra lateral -->
      <div class="admin-sidebar-profile">
        <div class="admin-profile-avatar">ML</div>
        <div class="admin-profile-meta">
          <span class="admin-profile-name">María López</span>
          <span class="admin-profile-role">Administradora</span>
        </div>
      </div>

    </aside>

    <!-- ÁREA DE CONTENIDO PRINCIPAL -->
    <main class="admin-main-content">
      <div class="admin-content-card">
        
        <!-- Encabezado de la Pantalla: Título y Filtro de Fechas -->
        <div class="admin-content-header">
          <div class="admin-title-group">
            <h1 class="admin-page-title">Resumen Analítico</h1>
            <p class="admin-page-subtitle">Rendimiento general y productos destacados del mes</p>
          </div>
          
          <!-- Botón Filtro de Rango de Fechas -->
          <button class="btn-date-range" id="btnDateFilter" type="button" title="Seleccionar rango de fechas">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            <span>01/09/2026 – 12/09/2026</span>
          </button>
        </div>

        <!-- Tarjetas KPI Superiores (Grid 2 columnas) -->
        <div class="kpi-grid">
          
          <!-- Tarjeta 1: Cantidad de Ventas -->
          <div class="kpi-card">
            <div class="kpi-header">
              <span class="kpi-title">Cantidad de ventas</span>
              <div class="kpi-icon-badge" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                  <polyline points="17 6 23 6 23 12"></polyline>
                </svg>
              </div>
            </div>
            <div class="kpi-value-group">
              <span class="kpi-value text-kpi-primary">321</span>
              <p class="kpi-subtext">Órdenes completadas con éxito</p>
            </div>
          </div>

          <!-- Tarjeta 2: Total Vendido -->
          <div class="kpi-card">
            <div class="kpi-header">
              <span class="kpi-title">Total vendido</span>
              <div class="kpi-icon-badge" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                  <rect x="2" y="6" width="20" height="12" rx="2"></rect>
                  <circle cx="12" cy="12" r="2.5"></circle>
                  <path d="M6 12h.01M18 12h.01"></path>
                </svg>
              </div>
            </div>
            <div class="kpi-value-group">
              <span class="kpi-value text-kpi-highlight">$158,000 USD</span>
              <p class="kpi-subtext">Ingresos brutos acumulados</p>
            </div>
          </div>

        </div>

        <!-- Tabla: Productos con mayor demanda (Top 5) -->
        <div class="ranking-table-card">
          
          <div class="ranking-header">
            <div class="ranking-title-group">
              <h2 class="ranking-card-title">Productos con mayor demanda</h2>
              <p class="ranking-card-subtitle">Clasificación de productos más ordenados</p>
            </div>
            <span class="ranking-badge-top">Top 5</span>
          </div>

          <!-- Tabla con las 3 columnas solicitadas -->
          <div class="table-responsive">
            <table class="ranking-table">
              <thead>
                <tr>
                  <th class="col-rank">Posición</th>
                  <th class="col-product">Producto</th>
                  <th class="col-qty">Cantidad vendida</th>
                </tr>
              </thead>
              <tbody>
                
                <!-- Fila 1: Posición 1 (Medalla Oro) -->
                <tr>
                  <td class="cell-rank">
                    <span class="rank-badge rank-gold">1</span>
                  </td>
                  <td class="cell-product">
                    <div class="rank-product-info">
                      <span class="rank-product-name">Café americano</span>
                      <span class="rank-product-price">$00.00 USD</span>
                    </div>
                  </td>
                  <td class="cell-qty">
                    <span class="rank-qty-val">86 uds.</span>
                  </td>
                </tr>

                <!-- Fila 2: Posición 2 (Medalla Plata) -->
                <tr>
                  <td class="cell-rank">
                    <span class="rank-badge rank-silver">2</span>
                  </td>
                  <td class="cell-product">
                    <div class="rank-product-info">
                      <span class="rank-product-name">Cappuccino</span>
                      <span class="rank-product-price">$00.00 USD</span>
                    </div>
                  </td>
                  <td class="cell-qty">
                    <span class="rank-qty-val">72 uds.</span>
                  </td>
                </tr>

                <!-- Fila 3: Posición 3 (Medalla Bronce) -->
                <tr>
                  <td class="cell-rank">
                    <span class="rank-badge rank-bronze">3</span>
                  </td>
                  <td class="cell-product">
                    <div class="rank-product-info">
                      <span class="rank-product-name">Brownie</span>
                      <span class="rank-product-price">$00.00 USD</span>
                    </div>
                  </td>
                  <td class="cell-qty">
                    <span class="rank-qty-val">61 uds.</span>
                  </td>
                </tr>

                <!-- Fila 4: Posición 4 -->
                <tr>
                  <td class="cell-rank">
                    <span class="rank-plain">4</span>
                  </td>
                  <td class="cell-product">
                    <div class="rank-product-info">
                      <span class="rank-product-name">Sándwich de pollo</span>
                      <span class="rank-product-price">$00.00 USD</span>
                    </div>
                  </td>
                  <td class="cell-qty">
                    <span class="rank-qty-val">54 uds.</span>
                  </td>
                </tr>

                <!-- Fila 5: Posición 5 -->
                <tr>
                  <td class="cell-rank">
                    <span class="rank-plain">5</span>
                  </td>
                  <td class="cell-product">
                    <div class="rank-product-info">
                      <span class="rank-product-name">Frappé de café</span>
                      <span class="rank-product-price">$00.00 USD</span>
                    </div>
                  </td>
                  <td class="cell-qty">
                    <span class="rank-qty-val">48 uds.</span>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>

          <!-- Pie del Card: Enlace centrado a reporte detallado -->
          <div class="ranking-footer-link">
            <a href="#" class="link-detail-report">
              <span>Ver reporte de inventario detallado</span>
              <span class="link-arrow">&rarr;</span>
            </a>
          </div>

        </div>

      </div>
    </main>

  </div>

  <script src="JS/main.js"></script>
</body>
</html>

