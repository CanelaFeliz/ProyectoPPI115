﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NIXGARU – Gestión de Cuentas de Personal</title>
  <!-- Google Fonts: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="CSS/style.css">
</head>
<body class="admin-body">

  <div class="admin-layout">

    <!-- BARRA LATERAL (SIDEBAR ADMIN OSCURA #382823) -->
    <aside class="admin-sidebar">
      
      <!-- Logotipo Admin -->
      <div class="admin-brand">
        <div class="admin-brand-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
            <line x1="6" y1="1" x2="6" y2="4"></line>
            <line x1="10" y1="1" x2="10" y2="4"></line>
            <line x1="14" y1="1" x2="14" y2="4"></line>
          </svg>
        </div>
        <div class="admin-brand-info">
          <span class="admin-brand-title">NIXGARU</span>
          <span class="admin-brand-sub">ADMINISTRACION</span>
        </div>
      </div>

      <!-- Menú de Navegación del Administrador -->
      <nav class="admin-nav">
        <!-- Catálogo y Menú (Enlace a admin_catalogo.php) -->
        <a href="admin_catalogo.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
          </svg>
          <span>Catálogo y Menú</span>
        </a>

        <!-- Gestión de Mesas (Enlace a admin_mesas.php) -->
        <a href="admin_mesas.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 3h18v18H3zM3 9h18M9 21V9"></path>
          </svg>
          <span>Gestión de Mesas</span>
        </a>

        <!-- Control de Inventarios (Enlace a admin_inventario.php) -->
        <a href="admin_inventario.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
            <line x1="12" y1="22.08" x2="12" y2="12"></line>
          </svg>
          <span>Control de Inventarios</span>
        </a>

        <!-- Cuentas de Personal (ACTIVO: Fondo blanco, texto oscuro y bordes redondeados) -->
        <a href="admin_personal.php" class="admin-nav-item active">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span>Cuentas de Personal</span>
        </a>

        <!-- Análisis y Reportes (Enlace a admin_dashboard.php) -->
        <a href="admin_dashboard.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="20" x2="18" y2="10"></line>
            <line x1="12" y1="20" x2="12" y2="4"></line>
            <line x1="6" y1="20" x2="6" y2="14"></line>
          </svg>
          <span>Análisis y Reportes</span>
        </a>
      </nav>

      <!-- Perfil de Administrador en el pie de la barra lateral -->
      <div class="admin-sidebar-profile">
        <div class="admin-profile-avatar">ML</div>
        <div class="admin-profile-meta">
          <span class="admin-profile-name">María López</span>
          <span class="admin-profile-role">Administradora</span>
        </div>
      </div>

    </aside>

    <!-- ÁREA DE CONTENIDO PRINCIPAL -->
    <main class="admin-main-content">
      <div class="admin-content-card">
        
        <!-- Encabezado de la Pantalla: Título y Botón Agregar Empleado -->
        <div class="admin-content-header">
          <div class="admin-title-group">
            <h1 class="admin-page-title">Gestión de Cuentas de Personal</h1>
            <p class="admin-page-subtitle">Administra el personal del sistema, asigna roles de servicio y controla accesos</p>
          </div>
          <button class="btn-add-table" id="btnAbrirModalEmpleado" type="button">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            <span>Agregar Empleado</span>
          </button>
        </div>

        <!-- Tarjetas Estadísticas Superiores -->
        <div class="admin-stats-row">
          
          <!-- Tarjeta 1: Personal Registrado -->
          <div class="admin-stat-card">
            <span class="stat-label">PERSONAL REGISTRADO</span>
            <div class="stat-value-group">
              <span class="stat-number">7 Trabajadores</span>
              <span class="stat-badge-active">Activos</span>
            </div>
          </div>

          <!-- Tarjeta 2: Estructura de Roles -->
          <div class="admin-stat-card">
            <span class="stat-label">ESTRUCTURA DE ROLES</span>
            <div class="stat-value-group">
              <span class="stat-number">5 Roles del sistema</span>
            </div>
          </div>

        </div>

        <!-- Contenedor de la Tabla: Listado de Personal -->
        <div class="admin-table-container">
          
          <div class="admin-table-header">
            <div class="table-header-left">
              <h2 class="table-card-title">Listado de Personal</h2>
              <p class="table-card-subtitle">Cuentas de usuario configuradas con accesos activos para el servicio de cafetería</p>
            </div>
            <span class="table-count-badge" id="personalCountBadge">Total: 2 mostrados</span>
          </div>

          <!-- Tabla de Datos -->
          <div class="table-responsive">
            <table class="admin-data-table">
              <thead>
                <tr>
                  <th class="col-id">ID</th>
                  <th class="col-emp-name">Nombre Completo</th>
                  <th class="col-emp-user">Usuario</th>
                  <th class="col-emp-role">Rol Asignado</th>
                  <th class="col-acciones">Acciones</th>
                </tr>
              </thead>
              <tbody id="tablaPersonalBody">
                
                <!-- Fila 1 -->
                <tr>
                  <td class="cell-id">U01</td>
                  <td class="cell-name">Ana Ruiz</td>
                  <td class="cell-user">aruiz</td>
                  <td class="cell-role">
                    <span class="role-pill">Administrador</span>
                  </td>
                  <td class="cell-acciones">
                    <button class="btn-action-edit" title="Editar empleado">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                      </svg>
                    </button>
                    <button class="btn-action-delete" title="Eliminar empleado">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                      </svg>
                    </button>
                  </td>
                </tr>

                <!-- Fila 2 -->
                <tr>
                  <td class="cell-id">U02</td>
                  <td class="cell-name">Luis Gil</td>
                  <td class="cell-user">lgil</td>
                  <td class="cell-role">
                    <span class="role-pill">Personal de servicio</span>
                  </td>
                  <td class="cell-acciones">
                    <button class="btn-action-edit" title="Editar empleado">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                      </svg>
                    </button>
                    <button class="btn-action-delete" title="Eliminar empleado">
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                      </svg>
                    </button>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>

          <!-- Pie de la Tabla -->
          <div class="admin-table-footer">
            <span>Mostrando 2 de 7 cuentas de personal activas</span>
          </div>

        </div>

      </div>
    </main>

  </div>

  <!-- MODAL: REGISTRAR NUEVO EMPLEADO (Oculto por defecto) -->
  <div id="modalNuevoEmpleado" class="modal" aria-hidden="true">
    <div class="modal-card">
      <div class="modal-header">
        <h3 class="modal-title">Nueva Cuenta</h3>
        <p class="modal-subtitle">Registra un nuevo empleado asignando credenciales de acceso.</p>
      </div>
      
      <form id="formNuevoEmpleado" class="modal-form">
        <!-- Campo: Nombre Completo -->
        <div class="form-group">
          <label for="inputNombreEmpleado" class="form-label">Nombre Completo</label>
          <input type="text" id="inputNombreEmpleado" class="form-input" placeholder="Ej. Ana Ruiz" required>
        </div>

        <!-- Campo: Nombre de Usuario -->
        <div class="form-group">
          <label for="inputUsuarioEmpleado" class="form-label">Nombre de Usuario</label>
          <input type="text" id="inputUsuarioEmpleado" class="form-input" placeholder="Ej. aruiz" required>
        </div>

        <!-- Campo: Contraseña -->
        <div class="form-group">
          <label for="inputPasswordEmpleado" class="form-label">Contraseña</label>
          <input type="password" id="inputPasswordEmpleado" class="form-input" placeholder="••••••••" required>
        </div>

        <!-- Campo: Rol Asignado -->
        <div class="form-group">
          <label for="selectRolEmpleado" class="form-label">Rol Asignado</label>
          <div class="select-wrapper">
            <select id="selectRolEmpleado" class="form-select" required>
              <option value="" disabled selected>Seleccionar Rol...</option>
              <option value="Administrador">Administrador</option>
              <option value="Personal de servicio">Personal de servicio</option>
              <option value="Cajero">Cajero</option>
              <option value="Cocinero">Cocinero</option>
              <option value="Barista">Barista</option>
            </select>
          </div>
        </div>

        <!-- Botones de Acción del Modal -->
        <div class="modal-actions">
          <button type="button" class="btn-modal-cancel" id="btnCancelarModalEmpleado">Cancelar</button>
          <button type="submit" class="btn-modal-save" id="btnGuardarEmpleado">Guardar Cuenta</button>
        </div>
      </form>
    </div>
  </div>

  <script src="JS/main.js"></script>
</body>
</html>

