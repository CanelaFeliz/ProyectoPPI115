﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NIXGARU – Plano de Mesas | Personal de Servicio</title>
  <!-- Preconexión y carga de Google Fonts: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="CSS/style.css">
</head>
<body>

  <!-- Encabezado / Header Personal de Servicio -->
  <header class="service-header">
    <div class="service-header-container">
      
      <!-- Logotipo e Identidad de Rol -->
      <div class="brand-logo-service">
        <div class="logo-icon-service">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
            <line x1="6" y1="1" x2="6" y2="4"></line>
            <line x1="10" y1="1" x2="10" y2="4"></line>
            <line x1="14" y1="1" x2="14" y2="4"></line>
          </svg>
        </div>
        <div class="logo-text-group">
          <span class="logo-brand-name">NIXGARU</span>
          <span class="logo-subtext">PERSONAL DE SERVICIO</span>
        </div>
      </div>

      <!-- Área de Usuario y Salida -->
      <div class="service-user-actions">
        <!-- Tarjeta de Perfil con datos dinámicos mediante ID -->
        <div class="user-profile-badge">
          <div class="user-avatar" id="avatarUsuario">CM</div>
          <div class="user-meta">
            <span class="user-name" id="nombreUsuario"></span>
            <span class="user-role" id="rolUsuario"></span>
          </div>
        </div>

        <!-- Botón de Cerrar Sesión -->
        <button class="btn-logout" id="btnCerrarSesion" title="Cerrar Sesión">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#C53145" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
            <polyline points="16 17 21 12 16 7"></polyline>
            <line x1="21" y1="12" x2="9" y2="12"></line>
          </svg>
          <span>Cerrar Sesión</span>
        </button>
      </div>

    </div>
  </header>

  <!-- Layout Principal: 70% Plano de Mesas / 30% Cuenta -->
  <main class="mesas-layout">

    <!-- COLUMNA IZQUIERDA (70%): Plano de Mesas -->
    <section class="mesas-panel">
      
      <!-- Cabecera del Panel con Leyenda de Estados -->
      <div class="panel-header">
        <div class="panel-title-group">
          <h1 class="panel-title">Plano de Mesas</h1>
          <p class="panel-subtitle">Vista en tiempo real del salón principal</p>
        </div>

        <!-- Leyenda de Estados -->
        <div class="status-legend">
          <span class="legend-badge badge-disponible">
            <span class="status-dot dot-disponible"></span>
            Disponible
          </span>
          <span class="legend-badge badge-ocupada">
            <span class="status-dot dot-ocupada"></span>
            Ocupada
          </span>
          <span class="legend-badge badge-proceso">
            <span class="status-dot dot-proceso"></span>
            En proceso
          </span>
          <span class="legend-badge badge-sin-servicio">
            <span class="status-dot dot-sin-servicio"></span>
            Sin servicio
          </span>
        </div>
      </div>

      <!-- Cuadrícula de 8 Mesas (CSS Grid) -->
      <div class="tables-grid">

        <!-- Mesa 1 (Seleccionada) -->
        <article class="table-card active" data-table-number="1" data-table-cap="4">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 1</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
              Cap. 4
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-disponible" aria-label="Estado de la Mesa 1">
                <option value="disponible" selected>Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 2 -->
        <article class="table-card" data-table-number="2" data-table-cap="2">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 2</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
              </svg>
              Cap. 2
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-ocupada" aria-label="Estado de la Mesa 2">
                <option value="disponible">Disponible</option>
                <option value="ocupada" selected>Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 3 -->
        <article class="table-card" data-table-number="3" data-table-cap="6">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 3</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
              Cap. 6
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-proceso" aria-label="Estado de la Mesa 3">
                <option value="disponible">Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso" selected>En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 4 -->
        <article class="table-card" data-table-number="4" data-table-cap="4">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 4</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
              </svg>
              Cap. 4
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-sin-servicio" aria-label="Estado de la Mesa 4">
                <option value="disponible">Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio" selected>Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 5 -->
        <article class="table-card" data-table-number="5" data-table-cap="4">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 5</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
              </svg>
              Cap. 4
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-disponible" aria-label="Estado de la Mesa 5">
                <option value="disponible" selected>Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 6 -->
        <article class="table-card" data-table-number="6" data-table-cap="2">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 6</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
              </svg>
              Cap. 2
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-ocupada" aria-label="Estado de la Mesa 6">
                <option value="disponible">Disponible</option>
                <option value="ocupada" selected>Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 7 -->
        <article class="table-card" data-table-number="7" data-table-cap="6">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 7</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
              </svg>
              Cap. 6
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-proceso" aria-label="Estado de la Mesa 7">
                <option value="disponible">Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso" selected>En proceso</option>
                <option value="sin-servicio">Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

        <!-- Mesa 8 -->
        <article class="table-card" data-table-number="8" data-table-cap="4">
          <div class="table-card-header">
            <h3 class="table-name">Mesa 8</h3>
            <span class="table-capacity">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                <circle cx="9" cy="7" r="4"></circle>
              </svg>
              Cap. 4
            </span>
          </div>
          <div class="table-card-body">
            <div class="table-data-row">
              <span class="data-label">Consumo:</span>
              <span class="data-value">$0.00</span>
            </div>
            <div class="table-data-row">
              <span class="data-label">Tiempo:</span>
              <span class="data-value">0 min</span>
            </div>
          </div>
          <div class="table-card-footer">
            <div class="status-select-wrapper">
              <select class="table-status-select status-sin-servicio" aria-label="Estado de la Mesa 8">
                <option value="disponible">Disponible</option>
                <option value="ocupada">Ocupado</option>
                <option value="proceso">En proceso</option>
                <option value="sin-servicio" selected>Sin servicio</option>
              </select>
            </div>
          </div>
        </article>

      </div>

      <!-- Barra de Resumen en la Base del Panel -->
      <footer class="tables-summary-bar">
        <div class="summary-counts">
          Resumen actual: 
          <strong>2 Disponibles</strong> | 
          <strong>2 Ocupadas</strong> | 
          <strong>2 En proceso</strong> | 
          <strong>1 Sin servicio</strong>
        </div>
        <div class="summary-sync">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <polyline points="1 20 1 14 7 14"></polyline>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
          </svg>
          <span>ACTUALIZADO HACE 1 MIN</span>
        </div>
      </footer>

    </section>

    <!-- COLUMNA DERECHA (30%): Cuenta de la Mesa -->
    <aside class="cuenta-panel">
      <div class="cuenta-card">
        
        <!-- Cabecera de la Cuenta -->
        <div class="cuenta-header">
          <h2 class="cuenta-title" id="cuentaMesaTitulo">Cuenta - Mesa 1</h2>
          <span class="legend-badge badge-disponible" id="cuentaMesaEstado">
            <span class="status-dot dot-disponible"></span>
            Disponible
          </span>
        </div>

        <!-- Sección de Productos -->
        <div class="cuenta-section-label">PRODUCTOS</div>

        <div class="cuenta-items-list" id="listaProductosCuenta">
          
          <!-- Producto 1 -->
          <div class="cuenta-item">
            <span class="item-qty-badge">2</span>
            <span class="item-name">Producto 1</span>
            <span class="item-price">$0.00</span>
          </div>

          <!-- Producto 2 -->
          <div class="cuenta-item">
            <span class="item-qty-badge">4</span>
            <span class="item-name">Producto 2</span>
            <span class="item-price">$0.00</span>
          </div>

          <!-- Producto 3 -->
          <div class="cuenta-item">
            <span class="item-qty-badge">1</span>
            <span class="item-name">Producto 3</span>
            <span class="item-price">$0.00</span>
          </div>

        </div>

        <!-- Totales de la Cuenta -->
        <div class="cuenta-totals">
          <div class="totals-line">
            <span>Subtotal</span>
            <span id="cuentaSubtotal">$0.00</span>
          </div>
          <div class="totals-line">
            <span>Propina</span>
            <span id="cuentaPropina">$0.00</span>
          </div>
          <div class="totals-line total-highlight">
            <span class="total-text">Total</span>
            <span class="total-amount" id="cuentaTotal">$0.00</span>
          </div>
        </div>

        <!-- Botones de Acción -->
        <div class="cuenta-actions">
          <button class="btn-account-add" id="btnAgregarProducto">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="16"></line>
              <line x1="8" y1="12" x2="16" y2="12"></line>
            </svg>
            <span>Agregar Producto</span>
          </button>

          <button class="btn-account-close" id="btnCerrarCuenta">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect>
              <line x1="1" y1="10" x2="23" y2="10"></line>
            </svg>
            <span>Cerrar Cuenta</span>
          </button>
        </div>

      </div>
    </aside>

  </main>

  <!-- Script Principal con la lógica requerida -->
  <script src="JS/main.js"></script>
</body>
</html>

