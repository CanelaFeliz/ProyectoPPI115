﻿<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NIXGARU – Control de Inventarios</title>
  <!-- Google Fonts: Poppins -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,400&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="CSS/style.css">
</head>
<body class="admin-body">

  <div class="admin-layout">

    <!-- BARRA LATERAL (SIDEBAR ADMIN OSCURA #382823) -->
    <aside class="admin-sidebar">
      
      <!-- Logotipo Admin -->
      <div class="admin-brand">
        <div class="admin-brand-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
            <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
            <line x1="6" y1="1" x2="6" y2="4"></line>
            <line x1="10" y1="1" x2="10" y2="4"></line>
            <line x1="14" y1="1" x2="14" y2="4"></line>
          </svg>
        </div>
        <div class="admin-brand-info">
          <span class="admin-brand-title">NIXGARU</span>
          <span class="admin-brand-sub">ADMINISTRACION</span>
        </div>
      </div>

      <!-- Menú de Navegación del Administrador -->
      <nav class="admin-nav">
        <!-- Catálogo y Menú (Enlace a admin_catalogo.php) -->
        <a href="admin_catalogo.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="7" height="7"></rect>
            <rect x="14" y="3" width="7" height="7"></rect>
            <rect x="14" y="14" width="7" height="7"></rect>
            <rect x="3" y="14" width="7" height="7"></rect>
          </svg>
          <span>Catálogo y Menú</span>
        </a>

        <!-- Gestión de Mesas (Enlace a admin_mesas.php) -->
        <a href="admin_mesas.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 3h18v18H3zM3 9h18M9 21V9"></path>
          </svg>
          <span>Gestión de Mesas</span>
        </a>

        <!-- Control de Inventarios (ACTIVO: Fondo blanco, texto oscuro y bordes redondeados) -->
        <a href="admin_inventario.php" class="admin-nav-item active">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
            <line x1="12" y1="22.08" x2="12" y2="12"></line>
          </svg>
          <span>Control de Inventarios</span>
        </a>

        <!-- Cuentas de Personal (Enlace a admin_personal.php) -->
        <a href="admin_personal.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span>Cuentas de Personal</span>
        </a>

        <!-- Análisis y Reportes (Enlace a admin_dashboard.php) -->
        <a href="admin_dashboard.php" class="admin-nav-item">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="20" x2="18" y2="10"></line>
            <line x1="12" y1="20" x2="12" y2="4"></line>
            <line x1="6" y1="20" x2="6" y2="14"></line>
          </svg>
          <span>Análisis y Reportes</span>
        </a>
      </nav>

      <!-- Perfil de Administrador en el pie de la barra lateral -->
      <div class="admin-sidebar-profile">
        <div class="admin-profile-avatar">ML</div>
        <div class="admin-profile-meta">
          <span class="admin-profile-name">María López</span>
          <span class="admin-profile-role">Administradora</span>
        </div>
      </div>

    </aside>

    <!-- ÁREA DE CONTENIDO PRINCIPAL -->
    <main class="admin-main-content">
      <div class="admin-content-card">
        
        <!-- Encabezado de la Pantalla: Título y Buscador -->
        <div class="admin-content-header">
          <div class="admin-title-group">
            <h1 class="admin-page-title">Control de Inventarios y Ajustes</h1>
            <p class="admin-page-subtitle">Gestión de stock físico, mermas e ingredientes para preparación</p>
          </div>
          
          <!-- Buscador de Ingredientes -->
          <div class="admin-search-wrapper">
            <svg class="search-input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
            <input type="text" id="inputBuscarIngrediente" class="admin-search-input" placeholder="Buscar ingrediente..." autocomplete="off">
          </div>
        </div>

        <!-- Tarjeta Principal: Tabla de Inventario -->
        <div class="inventory-table-card">
          
          <div class="inventory-card-header">
            <div class="inventory-title-group">
              <h2 class="inventory-card-title">Ingredientes y Consumibles</h2>
              <p class="inventory-card-subtitle">Lista de insumos activos y cantidades actuales estimadas</p>
            </div>
            <span class="inventory-badge-updated">Actualizado hoy</span>
          </div>

          <!-- Tabla con las 5 columnas solicitadas -->
          <div class="table-responsive">
            <table class="inventory-table" id="tablaInventario">
              <thead>
                <tr>
                  <th class="col-code">Código</th>
                  <th class="col-ingredient">Ingrediente</th>
                  <th class="col-unit">Unidad</th>
                  <th class="col-qty">Cantidad Estimada</th>
                  <th class="col-adjust">Ajuste Manual</th>
                </tr>
              </thead>
              <tbody id="tablaInventarioBody">
                
                <!-- Fila 1: Alerta Stock Bajo (Café molido) -->
                <tr class="row-stock-alert">
                  <td class="cell-code text-danger">I01</td>
                  <td class="cell-ingredient">
                    <span class="ingredient-name">Café molido</span>
                    <span class="badge-stock-low">STOCK BAJO</span>
                  </td>
                  <td class="cell-unit">lb</td>
                  <td class="cell-qty">
                    <strong class="qty-val-danger">15.50</strong>
                    <span class="unit-text">lb</span>
                  </td>
                  <td class="cell-adjust">
                    <div class="adjust-control-group">
                      <input type="number" step="0.01" class="input-adjust" value="0.00" aria-label="Ajuste manual para Café molido">
                      <button type="button" class="btn-adjust-save">Guardar</button>
                    </div>
                  </td>
                </tr>

                <!-- Fila 2: Normal (Leche) -->
                <tr>
                  <td class="cell-code">I03</td>
                  <td class="cell-ingredient">
                    <span class="ingredient-name">Leche</span>
                  </td>
                  <td class="cell-unit">L</td>
                  <td class="cell-qty">
                    <strong class="qty-val-normal">22.00</strong>
                    <span class="unit-text">L</span>
                  </td>
                  <td class="cell-adjust">
                    <div class="adjust-control-group">
                      <input type="number" step="0.01" class="input-adjust" value="0.00" aria-label="Ajuste manual para Leche">
                      <button type="button" class="btn-adjust-save">Guardar</button>
                    </div>
                  </td>
                </tr>

                <!-- Fila 3: Normal (Huevo) -->
                <tr>
                  <td class="cell-code">I13</td>
                  <td class="cell-ingredient">
                    <span class="ingredient-name">Huevo</span>
                  </td>
                  <td class="cell-unit">unidad</td>
                  <td class="cell-qty">
                    <strong class="qty-val-normal">30.00</strong>
                    <span class="unit-text">unidad</span>
                  </td>
                  <td class="cell-adjust">
                    <div class="adjust-control-group">
                      <input type="number" step="0.01" class="input-adjust" value="0.00" aria-label="Ajuste manual para Huevo">
                      <button type="button" class="btn-adjust-save">Guardar</button>
                    </div>
                  </td>
                </tr>

                <!-- Fila 4: Normal (Croissant) -->
                <tr>
                  <td class="cell-code">I24</td>
                  <td class="cell-ingredient">
                    <span class="ingredient-name">Croissant</span>
                  </td>
                  <td class="cell-unit">unidad</td>
                  <td class="cell-qty">
                    <strong class="qty-val-normal">12.00</strong>
                    <span class="unit-text">unidad</span>
                  </td>
                  <td class="cell-adjust">
                    <div class="adjust-control-group">
                      <input type="number" step="0.01" class="input-adjust" value="0.00" aria-label="Ajuste manual para Croissant">
                      <button type="button" class="btn-adjust-save">Guardar</button>
                    </div>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>

          <!-- Mensaje de no resultados (oculto por defecto) -->
          <div id="noResultadosInventario" class="no-results-msg" style="display: none;">
            No se encontraron ingredientes que coincidan con la búsqueda.
          </div>

          <!-- Pie de la Tarjeta: Enlace Centrado -->
          <div class="inventory-footer-link">
            <a href="#" class="link-detail-report">
              <span>Ver reporte de inventario detallado</span>
              <span class="link-arrow">&rarr;</span>
            </a>
          </div>

        </div>

      </div>
    </main>

  </div>

  <script src="JS/main.js"></script>
</body>
</html>

